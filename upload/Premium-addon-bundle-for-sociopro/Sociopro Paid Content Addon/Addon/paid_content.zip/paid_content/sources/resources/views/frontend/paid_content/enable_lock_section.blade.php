<div class="entry-img locked">
    <img src="{{ asset('assets/frontend/images/' . $cover_pic) }}" class="img-fluid" alt="" />
    <div class="locked-info">
        <span>
            <i class="fa-solid fa-lock"></i>
            Locked
        </span>
        <p class="info">
            This post is locked.<br>Get a subscription to unlock this post.
        </p>
        <a href="#">Join Now</a>
    </div>
</div>
