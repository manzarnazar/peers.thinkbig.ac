 <div class="tab-content" id="v-pills-tabContent">
     @include('frontend.fundraiser.explore_tab')
 </div>
