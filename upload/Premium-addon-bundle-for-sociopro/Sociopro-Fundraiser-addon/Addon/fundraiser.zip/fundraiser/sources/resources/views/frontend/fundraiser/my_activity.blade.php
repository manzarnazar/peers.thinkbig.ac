<!-- Main Start -->
<main class="main-section">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 profile-menu-panel">
                @include('frontend.fundraiser.activity_left_navigation')
            </div>
            <div class="col-lg-9">
               
                @include($section)
            </div>

        </div>
        <!-- row end -->
    </div>
    <!-- container end -->
</main>
<!-- Main End -->
