{{-- @include('frontend.fundraiser.left_navigation') --}}
{{-- <div class="col-xl-9 col-lg-8"> --}}
    @include($section)
{{-- </div> --}}
