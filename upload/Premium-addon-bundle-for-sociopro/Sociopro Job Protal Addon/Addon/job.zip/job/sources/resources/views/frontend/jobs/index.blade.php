{{-- @include('frontend.jobs.job_left_navigation') --}}
<div class="col-xl-12 col-lg-12">
    @include($section)
</div>
